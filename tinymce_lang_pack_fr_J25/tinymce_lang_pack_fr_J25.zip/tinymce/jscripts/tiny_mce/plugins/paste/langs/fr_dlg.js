// FR lang variables - Sarki pour Joomla! FR 2011-07-17
tinyMCE.addI18n('fr.paste_dlg',{
text_title:"Utilisez les touches CTRL+V pour coller le texte dans la fen\u00EAtre",
text_linebreaks:"Conserver les sauts de ligne",
word_title:"Utilisez les touches CTRL+V pour coller le texte dans la fen\u00EAtre"
});