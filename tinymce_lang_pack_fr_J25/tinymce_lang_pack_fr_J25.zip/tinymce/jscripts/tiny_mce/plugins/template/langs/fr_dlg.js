// FR lang variables - Sarki pour Joomla! FR 2011-07-17
tinyMCE.addI18n('fr.template_dlg',{
title:"Gabarit de mise en page",
label:"Mise en page",
desc_label:"Description",
desc : 'Ins\u00E9rer/Sauver une mise en page',
select:"S\u00E9l\u00E9ctionnez le gabarit",
preview:"Pr\u00E9visualiser",
warning:"Attention: changer de mise en page peut supprimer des \u00E9l\u00E9ments du contenu",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"Janvier,F\u00E9vrier,Mars,Avril,Mai,Juin,Juillet,Ao\u00FBt,Septembre,Octobre,Novembre,D\u00E9cembre",
months_short:"Jan,F\u00E9v,Mar,Avr,Mai,Jun,Jul,Ao\u00FB,Sep,Oct,Nov,D\u00E9c",
day_long:"Dimanche,Lundi,Mardi,Mercredi,Jeudi,Vendredi,Samedi,Dimanche",
day_short:"Dim,Lun,Mar,Mer,Jeu,Ven,Sam,Dim"
});
