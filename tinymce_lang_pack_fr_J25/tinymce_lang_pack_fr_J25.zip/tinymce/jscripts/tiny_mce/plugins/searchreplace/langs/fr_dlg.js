// FR lang variables - Sarki pour Joomla! FR 2011-07-17
tinyMCE.addI18n('fr.searchreplace_dlg',{
searchnext_desc:"Trouver d'autres r\u00E9sultats",
notfound:"La recherche a \u00E9t\u00E9 effectu\u00E9e avec succ\u00E8s mais aucun r\u00E9sultat n'a pas pu \u00EAtre trouv\u00E9.",
search_title:"Rechercher",
replace_title:"Rechercher/Remplacer",
allreplaced:"Tous les \u00E9l\u00E9ments trouv\u00E9s ont \u00E9t\u00E9 remplac\u00E9s avec succ\u00E8s.",
findwhat:"Rechercher...",
replacewith:"Remplacer par",
direction:"Direction",
up:"Vers le haut",
down:"Vers le bas",
mcase:"Respecter la casse",
findnext:"Suivant",
replace:"Remplacer",
replaceall:"Remplacer tous"
});