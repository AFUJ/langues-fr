// FR lang variables - Sarki pour Joomla! FR 2011-07-17
tinyMCE.addI18n('fr.autosave',{
restore_content: "Restaurer la sauvegarde automatique",
warning_message: "La restauration de la sauvegarde remplacera le contenu.\n\nVoulez-vous continuer ?"
});